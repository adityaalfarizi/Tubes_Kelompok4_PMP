#ifndef FILEIO_H
#define FILEIO_H

#include "dokter.h"

void simpan_jadwal_ke_file(const char* filename);

#endif