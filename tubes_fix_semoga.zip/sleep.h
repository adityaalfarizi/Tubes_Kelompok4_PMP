#ifndef SLEEP_H
#define SLEEP_H
#include "dokter.h"

void jeda(int detik);
void string_to_upper(char *str);
#endif