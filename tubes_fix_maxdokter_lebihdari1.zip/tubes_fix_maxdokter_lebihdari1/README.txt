1. bersihkan projek lama
mingw32-make clean

2. kompilasi ulang
mingw32-make

3. jalankan program
./jadwal.exe
start uiux.html (ui ux html)


format file teks .csv dengan isinya 
Nama,MaksShift,Preferensi
Rafif,2,PAGI
Budi,3,SIANG

